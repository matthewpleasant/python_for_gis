import arcpy

arcpy.env.overwriteOutput = True

#Variables

use = arcpy.GetParameterAsText(0)
use = use.split(";")
use = [ u.replace("'", "") for u in use ]
m1 = "Types of land use: ", use
arcpy.AddMessage(m1)

trailType = arcpy.GetParameterAsText(1)
trailType = trailType.split(";")
m2 = "Types of trails: ", trailType
arcpy.AddMessage(m2)
#trailType = [ p.replace("'", "") for p in trailType ]

roadType = arcpy.GetParameterAsText(2)
roadType = roadType.split(";")
roadType = [ r.replace("'", "") for r in roadType ]
m3 = "Types of roads: ", roadType
arcpy.AddMessage(m3)

trailDist = arcpy.GetParameterAsText(3)
m4 = "Trail buffer distance: ", trailDist
arcpy.AddMessage(m4)

roadDist = arcpy.GetParameterAsText(4)
m5 = "Road buffer distance: ", roadDist
arcpy.AddMessage(m5)

size = arcpy.GetParameterAsText(5)
m6 = "Minimum campground area: ", size
arcpy.AddMessage(m6)

ws = arcpy.GetParameterAsText(6)

arcpy.env.workspace = ws

output = "/d2outputs/"

outlist = []

featureCount = 0

areaSizes = []


## GEOPROCESSING ##

arcpy.Select_analysis("floods", ws + output + "flood", "SFHA = 'IN'")

for t in trailType:
    arcpy.Select_analysis("trails", ws + output + t, "SURFACE = '" + t + "'")
    arcpy.Buffer_analysis(output + t, ws + output + "trailbuff" + trailDist, trailDist + " Meters", "FULL", "ROUND", "ALL", "", "PLANAR")
    for r in roadType:
        arcpy.Select_analysis("majroads", ws + output + r, "DESCRIPT = '" + r + "'")
        arcpy.Buffer_analysis(ws + output + r, ws + output + "roadbuff" + roadDist, roadDist + " Meters", "FULL", "ROUND", "ALL", "", "PLANAR")        
        for l in use:
            arcpy.Select_analysis("landuse", ws + output + l.replace(" ", ""), "LEVEL1 = '" + l + "'")
            arcpy.Clip_analysis(ws + output + l.replace(" ", ""), ws + output + "flood", ws + output + "flood" + l.replace(" ", "") + "clip")
            arcpy.Intersect_analysis([output + "flood" + l.replace(" ", "") + "clip", output + "trailbuff" + trailDist], output + l.replace(" ", "") + "trail" + trailDist)
            arcpy.Erase_analysis(ws + output + l.replace(" ", "") + "trail" + trailDist, ws + output + "roadbuff" + roadDist, ws + output + "semifinal")
            outstring = ws + output + l.replace(" ", "") + t + trailDist + roadDist
            arcpy.Select_analysis(ws + output + "semifinal", outstring, "Shape_Area >= " + size)
            outlist.append(outstring)
            result = arcpy.GetCount_management(outstring)
            count = int(result.getOutput(0))
            featureCount = featureCount + count
            sc = arcpy.da.SearchCursor(outstring, "Shape_Area")
            for r in sc:
                a = float(sc[0])
                areaSizes.append(a)
            

res = ";".join(outlist)
arcpy.SetParameterAsText(7, res)

if featureCount > 0:
    m7 = "Total number of features: ", str(featureCount)
    arcpy.AddMessage(m7)
else:
    "No features found"

min = min(areaSizes)
max = max(areaSizes)

min = "Smallest feature area: " + str(min) + " square meters"
max = "Largest feature area: " + str(max) + " square meters"

arcpy.AddMessage(min)
arcpy.AddMessage(max)