import arcpy
env.overwriteOutput=1

wksp = arcpy.env.workspace = "C:/Users/mpleasan/Desktop/Class12/class12ex2/"

lu = ["TRANSPORT", "FOREST","URBAN","RANGELAND"]
sr = [15,60]

class ArcWarning(Exception): pass
class lowFeat(Exception): pass

for l in lu:   
    area = []
    try:
        arcpy.Select_analysis("C:/Users/mpleasan/Desktop/Class12/class12ex2/landuse.shp", l + "_SR_Select", '"DESCRIPT" = ' + "'" + l + "'" + ' and "SR" < ' + str(float(sr[0])) + ' or "DESCRIPT" =' + "'" + l + "'" + 'and "SR" > ' + str(float(sr[1])))      
    except arcpy.ExecuteError as e:
        print e.message
    try:
        result = arcpy.GetCount_management(wksp + l + "_SR_Select.shp")
        count = int(result.getOutput(0))
        if count == 0:
            raise ArcWarning
        elif count < 4:
            raise lowFeat
        else:
            sc = arcpy.da.SearchCursor(l + "_SR_Select.shp", 'Shape_Area')
            for r in sc:
                area.append(r[0])
                avgArea = sum(area)/len(area)
            print avgArea
            del sc
    except ArcWarning:
        print "No features exist with the select tool applied with: " + l, sr[0], sr[1]
        messages = arcpy.GetMessageCount()
        print arcpy.GetMessage(messages - 1)
    except lowFeat:
        print "No calculation performed. Fewer than four features found."
    finally:
        print "Script is continuing."