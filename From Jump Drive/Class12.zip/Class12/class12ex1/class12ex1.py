import arcpy, random
from arcpy import env

env.workspace = "C:/Users/mpleasan/Desktop/class12ex1/class12.gdb/data2/"
env.overwriteOutput=True

try:
    Alist = ["a9","a10",""] 
    r1 = random.randint(0,2)
    A = Alist[r1]
    arcpy.Select_analysis("landuse", A, "LEVEL1 = 'AGRICULTURE'")
    intstring = str(A) + "#;" + "a2 #; a6 #; a4#; a5 #"
except arcpy.ExecuteError as e:
    print arcpy.GetMessages()
    intstring = "a2 #;a6 #;a4#;a5 #"

try:
    Blist = [250, 500, 750]
    r2 = random.randint(0,4)
    B = Blist[r2]
    bdist = str(B) + " Meters"
    arcpy.Buffer_analysis("railways", "a2", bdist, "FULL", "ROUND", "ALL", "")
except IndexError:
    print "IndexError"
    arcpy.Buffer_analysis("railways", "a2", "400 Meters", "FULL", "ROUND", "ALL", "")

arcpy.SetSeverityLevel(1)
try:
    Clist = ["P1","P2","P3"]
    r3 = random.randint(0,2)
    C = Clist[r3]
    sql1 = "DESCRIPT = '" + C + "'"
    arcpy.Select_analysis("majroads", "a3", sql1)
    arcpy.Buffer_analysis("a3", "a6", "500 Meters", "FULL", "ROUND", "ALL", "")
except arcpy.ExecuteWarning as e:
    print e.message

arcpy.Select_analysis("floods", "a4", "SFHA = 'OUT'")
arcpy.Buffer_analysis("trails", "a5", "500 Meters", "FULL", "ROUND", "ALL", "")
arcpy.Intersect_analysis(intstring, "final", "ONLY_FID", "", "INPUT")